const editForm = document.getElementById("edit-form");

editForm.addEventListener("submit", handleEditSubmission);

async function handleEditSubmission(event){
    event.preventDefault();

    const id = event.currentTarget.querySelector(".id").value;
    const title = event.currentTarget.querySelector(".title").value;
    const author = event.currentTarget.querySelector(".author").value;
    const views = event.currentTarget.querySelector(".views").value;
    const content = event.currentTarget.querySelector(".content").value;

    if (!id || !title || !author || !views || !content){
        console.log("Missing Information");
        return;
    }

    const dataObj = {
        id: id,
        title: title,
        channel: author,
        views: views
    }

    const data = {
        method: "PUT",
        header: {
            "Content-Type" : "application/json"
        },
        body: JSON.stringify(dataObj)
    };

    fetch(`/api/post/${id}`, data);
    window.location.href = "/";
}

async function initiateEditForum(){
    const linkString = window.location.pathname;
    const linkArr = linkString.split("/");
    const id = linkArr[2];

    const post = await fetch(`/api/post/${id}`);
 
    const id = editForm.querySelector(".id").value;
    const title = editForm.querySelector(".title").value;
    const author = editForm.querySelector(".author").value;
    const views = editForm.querySelector(".views").value;
    const content = editForm.querySelector(".content").value;

    id = post.id;
    title = post.title;
    author = post.author;
    views = post.views;
    content = post.content;
}

initiateEditForum();